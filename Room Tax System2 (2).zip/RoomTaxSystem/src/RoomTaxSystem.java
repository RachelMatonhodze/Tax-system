import java.io.FileNotFoundException; //Used for error handling.
import java.io.FileReader; //Allows you to read what is in the File.
import java.util.Scanner; //Used to create an object that can then be used for user input. 
public class RoomTaxSystem {

	public static void  main(String[] args) throws FileNotFoundException { //This means the method can throw FileNotFoundException. An object of FileNotFoundException is thrown by the code if the file can't be found.
		// TODO Auto-generated method stub
        
		//Allows you to read from the "rooms.txt" file. 
        Scanner inFile = new Scanner(new FileReader("rooms.txt"));
        //Creates a new scanner which takes input from the console.
        Scanner console = new Scanner (System.in);
        
        //Declaring variables and constants. 
        double TaxRate = 20.0;      
        String RoomType = null;
        int Bookings = 0;
        float RoomPrice = 0;
        double Income = 0;   
        double Tax = 0;   
        float TotalIncome = 0; 
        double TotalTax = 0;
        
        //This is the text that is going to appear when the code runs.
        System.out.println("\t\tWelcome, Manager");
        System.out.println("\t********************************");
        System.out.println("Do you wish to specify a Custom Tax Rate? (yes/no): "); //User has to enter either "yes" or "no" in order to move on.
        
        String yesOrno = (console.nextLine()); //Stores data from the current line,into the console.
         if (yesOrno.equals("yes")) { //This means if the answer is "yes". This is an if statement (a Selection Statement). If the statement is true, the porgram will carry out an action.
        	System.out.println("Please enter the Tax Rate: ");
		    TaxRate =  console.nextDouble(); //This scans the next input (which is going to be the Tax Rate) as a double. 
		     System.out.println("--Room Tax System--");	//"System.out.println" is used to print an argument (string concatenation).	    
	         System.out.printf("\n"); // "\n" means insert a newline character."System.out.printf" is used for string formatting e.g, using placeholders, which will then be automatically replaced with the values we have.
	         System.out.println("Specify Custom Tax Rate [Y|N]:Y");
	         System.out.println("Specify Tax Rate (%) :" + TaxRate); //The input that was written by the user (TaxRate) is added next to the "Specify Tax Rate (%)".
	         System.out.printf("\n");
	         System.out.printf("\n");
         }
	        
            
         else if (yesOrno.equals("no")) { //This means or else if the answer is "no". This is an else if statement (a Selection Statement). If the "if" statement is false, else if gives another solution.	    	    
	         System.out.println("--Room Tax System--");
	         System.out.printf("\n");
	         System.out.println("Assuming Tax Rate (%) = "+ TaxRate); //After the user enters "no", it'll automatically enter the TaxRate variable that was declared (20.0) and also it will display the room data with the prices for 20% defult tax rate. 
	         System.out.printf("\n");
		     System.out.printf("\n");
         }                     
                
         while (inFile.hasNext()) //This is a while loop (an Iterative Statement) which allows the code to be executed repeatedly."(inFile.hasNext())" will read the file and returns true if the inFile scanner has another token in its input.
            	
	         {  //Reads lines from the "rooms.txt" file.
	         	RoomType = inFile.next(); 
	         	Bookings = inFile.nextInt();
	         	RoomPrice = inFile.nextFloat();
	         	
	         	//Calculations
	         	Income =  (Bookings)*(RoomPrice);	         	
	         	Tax =  ((Income)*(TaxRate/100)); //"*" means mulitiply."/" means divide.    	         	
	         	TotalIncome +=(Income);	// "+=" is a compound addition assignment operator that adds the value of the right variable (in this case, the Income) to the variable on the left (TotalIncome) and then gives the result of the variable.
	         	TotalTax += (Tax);
	       
	         //This outputs the record data.	
	         System.out.printf("Room Type:%s, Bookings:%d, RoomPrice:�%.2f, Income:�%.2f, Tax:�%.2f\n", RoomType, Bookings, RoomPrice, Income,Tax);  
	         		
	         }
	         //This outputs the totals.
	         System.out.printf("\nTotal Income:�%.2f\n", TotalIncome);
	     	 System.out.printf("Total Tax:�%.2f",TotalTax);
	     	
	     	 //Closes file.
	     	 inFile.close();
	     	 
	     	 //Closes console.
	     	 console.close();
	     	
	   
         }
	}

	
	 
         

